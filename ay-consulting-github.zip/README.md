# AY Consulting — Site vitrine

Site statique (HTML/CSS/JS) de Laly Ange Yoboue, consultant en Relation Client et Performance Commerciale.

## Mettre le site en ligne avec GitHub Pages

1. Créez un compte sur https://github.com puis un nouveau dépôt (par exemple `ay-consulting`), en **Public**.
2. Cliquez sur **Add file → Upload files** et glissez tout le contenu de ce dossier : `index.html`, le dossier `assets`, `.nojekyll` et `README.md`. Validez avec **Commit changes**.
3. Allez dans **Settings → Pages**. Dans **Build and deployment**, choisissez **Deploy from a branch**, puis la branche `main` et le dossier `/ (root)`. Enregistrez.
4. Après une à deux minutes, le site est disponible à l'adresse `https://VOTRE-NOM.github.io/ay-consulting/`.

## Nom de domaine personnalisé (facultatif)

Dans **Settings → Pages → Custom domain**, saisissez votre domaine (ex. `ay-consulting.com`), puis configurez chez votre registrar les enregistrements DNS indiqués par GitHub.

## Modifier le site

- Textes, prix, liens : éditez `index.html`.
- Photo et affiche : remplacez les fichiers dans `assets/` en gardant les mêmes noms.
- Après le 12 octobre 2026, retirez la section `id="masterclass"` dans `index.html`.

## Contact affiché sur le site

WhatsApp / téléphone : 07 17 10 90 62 · E-mail : optikliconsulting@gmail.com
